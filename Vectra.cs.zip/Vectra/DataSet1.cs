﻿namespace Vectra {
    
    
    public partial class DataSet1 {
    }
}

namespace Vectra.DataSet1TableAdapters {
    
    
    public partial class productsTableAdapter {
    }
}
