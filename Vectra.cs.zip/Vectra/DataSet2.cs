﻿namespace Vectra {
    
    
    public partial class DataSet2 {
        partial class PaymentAdjustRptDataTable
        {
        }
    
        partial class debtors_summaryDataTable
        {
        }
    
        partial class invoice_itemsDataTable
        {
        }
    }
}

namespace Vectra.DataSet2TableAdapters {
    partial class SalesSummary1TableAdapter
    {
    }
    
    
    public partial class INVOICE_HEADERTableAdapter {
    }
}
